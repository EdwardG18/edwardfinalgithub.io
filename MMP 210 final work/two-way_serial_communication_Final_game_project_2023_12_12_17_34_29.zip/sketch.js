let song;
function preload() {
  soundFormats('mp3', 'ogg');
 song = loadSound('mario.mp3');
}
let mario;
let gravity = 0.3;
let jumpForce = -7;
let isJumping = false;
let clouds = [];
let score = 0;
let HP= 3



//may not work on safari
// Declare a "SerialPort" object
var serial;

// fill in the name of your serial port here:
//copy this from the serial control app
var portName = "COM12";

//this array will hold transmitted data
var inMessage = 0;
var oldmessage= 0;

function setup() {
  createCanvas(700, 400);
  mario = new Mario();

  // Create initial clouds
  for (let i = 0; i < 5; i++) {
    clouds.push(new Cloud(random(width), random(50, 150)));
  }

  // make an instance of the SerialPort object
  serial = new p5.SerialPort();

  // Get a list the ports available
  // You should have a callback defined to see the results. See gotList, below:
  serial.list();

  // Assuming our Arduino is connected,  open the connection to it
  serial.open(portName);

  // When you get a list of serial ports that are available
  serial.on('list', gotList);

  // When you some data from the serial port
  serial.on('data', gotData);
}


// Got the list of ports
function gotList(thelist) {
  // theList is an array of their names
  for (var i = 0; i < thelist.length; i++) {
    // Display in the console
    console.log(i + " " + thelist[i]);
  }
}

// Called when there is data available from the serial port
function gotData() {
  var currentString = serial.readLine();  // read the incoming data
  trim(currentString);                    // trim off trailing whitespace
  if (!currentString) return;             // if the incoming string is empty, do no more
  // console.log(currentString);
      inMessage = currentString;   // save the currentString to use for the text
}

function draw() {
   background("#87CEEB"); // Sky Blue

  // Move and display clouds
  for (let cloud of clouds) {
    cloud.move();
    cloud.display();

    // Check if Mario has successfully jumped over the cloud
    if (mario.isOverCloud(cloud)) {
      score++;
    }
  }

  // Display score
  fill("#000000"); // Black
  textSize(20);
  text("Score: " + score, 20, 30);

 if (inMessage ==1 || inMessage == 5){
   // if (!isJumping){
   mario.jump();
   //   score++
   // }
 }
 if (inMessage == 2) {
   if (inMessage != oldmessage){
   HP--
   }

 }
  
  if(HP==3){
    ellipse(20,40,20,20);
    ellipse(20,70,20,20);
    ellipse(20,100,20,20);
  }
   else if(HP==2){
     ellipse(20,40,20,20);
    ellipse(20,70,20,20);
  }
  else if(HP==1){
    ellipse(20,40,20,20);
  }
  else{
    text("you lose", 100,100);
    noLoop();
    song.stop()
  }
  console.log(HP);
  mario.update();
  mario.display();
  
  oldmessage = inMessage;
}
function keyPressed() {
  if (keyCode === UP_ARROW && !isJumping) {
    mario.jump();
  }
}

class Mario {
  constructor() {
    this.width = 30;
    this.height = 50;
    this.x = width / 2 - this.width / 2;
    this.y = height - this.height;
    this.ySpeed = 0;
  }

  jump() {
    this.ySpeed = jumpForce;
    isJumping = true;
  }

  update() {
    this.ySpeed += gravity;
    this.y += this.ySpeed;

    // Check if Mario has landed
    if (this.y >= height - this.height) {
      this.y = height - this.height;
      this.ySpeed = 0;
      isJumping = false;
    }
  }

  display() {
    fill("#FF0000"); // Red
    rect(this.x, this.y, this.width, this.height);
  }

  isOverCloud(cloud) {
    // Check if Mario is over the cloud horizontally
    if (
      this.x + this.width > cloud.x &&
      this.x < cloud.x + cloud.size &&
      this.y + this.height > cloud.y &&
      this.y < cloud.y + cloud.size / 2
    ) {
      return true;
    }
    return false;
  }
}

class Cloud {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 1;
    this.size = random(30, 60);
  }

  move() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = -this.size;
      this.y = random(50, 150);
    }
  }

  display() {
    fill("#FFFFFF"); // White
    noStroke();
    ellipse(this.x, this.y, this.size, this.size / 2);
  }
}



// function mousePressed(){
//   serial.write("1");
// }
// function mouseReleased(){
//   serial.write("0");
// }

// function mouseReleased(){
//   serial.write("2");
// }

// function mouseReleased(){
//   serial.write("3");
// }


function mousePressed(){
  if (!song.isPlaying()){   
  
  song.play();
  }
  else{
   song.stop()
  }
}

